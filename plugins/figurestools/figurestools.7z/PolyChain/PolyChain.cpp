#include "PolyChain.h"

bool X_PolyChain::resourcesInited = false;

EXPORT_PLUGIN( X_PolyChain, FigureToolInterface )
