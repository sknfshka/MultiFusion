#include "Bezier.h"

bool Z_Bezier::resourcesInited = false;

EXPORT_PLUGIN( Z_Bezier, FigureToolInterface )
